package org.autotest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class StackArTest {

    @Test
    public void testExample() {
        StackAr stack = new StackAr();

        assertTrue(true);
        assertFalse(false);
        assertEquals(true, true);
    }
}
