#!./venv/bin/python
import unittest
from src.cgi_decode_instrumented import cgi_decode_instrumented


class TestEvaluateConditionForCgiDecodeInstrumented(unittest.TestCase):
    def testExample(self):
        cgi_decode_instrumented("Hello+Reader")
        self.assertTrue(True)
        self.assertFalse(False)
        self.assertEqual(True, True)