#!./venv/bin/python
import unittest
from src.create_population import create_population


class TestCreatePopulation(unittest.TestCase):
    def testExample(self):
        create_population(5)
        self.assertTrue(True)
        self.assertFalse(False)
        self.assertEqual(True, True)