def evaluate_population(population):
    fitness = {}
    # TODO: COMPLETAR
    return fitness
