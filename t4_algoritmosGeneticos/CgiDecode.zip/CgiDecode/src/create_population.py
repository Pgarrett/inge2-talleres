def create_population(population_size):
    population = []
    # TODO: COMPLETAR
    return population
