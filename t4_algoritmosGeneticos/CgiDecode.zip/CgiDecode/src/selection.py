def selection(evaluated_population, tournament_size):
    winner = None
    # TODO: COMPLETAR
    return winner
