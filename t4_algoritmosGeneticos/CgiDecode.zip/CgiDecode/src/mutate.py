def mutate(individual, seed=None):
    mutated_individual = None
    # TODO: COMPLETAR
    return mutated_individual
