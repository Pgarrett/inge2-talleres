def get_fitness_cgi_decode(test_suite):
    fitness = 0
    # TODO: COMPLETAR
    return 0
