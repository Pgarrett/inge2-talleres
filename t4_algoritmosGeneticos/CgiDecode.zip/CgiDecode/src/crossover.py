def crossover(parent1, parent2, seed=None):
    offspring1 = None
    offspring2 = None
    # TODO: COMPLETAR
    return offspring1, offspring2
